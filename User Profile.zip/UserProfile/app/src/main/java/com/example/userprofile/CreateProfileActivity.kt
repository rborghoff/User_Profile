package com.example.userprofile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_createprofileactivity.*

const val GALLERY_REQUEST_CODE = 100

class CreateProfileActivity : AppCompatActivity() {
    private var profileImageUri: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)
        setContentView(R.layout.activity_createprofileactivity)
        initViews()
    }

 fun initViews(){
     btnOpen.setOnClickListener{onGalleryClick()}
        btnConfirm.setOnClickListener{onGalleryClick()}
    }

    private fun onConfirmClick(){
        val profile = Profile(
            etName.text.toString(),
            etLastName.text.toString(),
            etDescrition.text.toString(),
            profileImageUri
        )
        val profileActivityIntent =Intent(this, ProfileActivity : : class.java)
        profileActivityIntent.putExtra(ProfileActivity.PROFILE_EXTRA, profile)startActivity(profileActivityIntent)
    }

    private fun onGalleryClick(){
        val galleryIntent = Intent(Intent.ACTION_PICK)
        galleryIntent.type = "image/*"
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == Activity.RESULT_OK){
        when(requestCode){
            GALLERY_REQUEST_CODE ->{
                profileImageUri = data?.data
                ivAvatar.setImageURI(profileImageUri)
            }
        }
        }
    }

}