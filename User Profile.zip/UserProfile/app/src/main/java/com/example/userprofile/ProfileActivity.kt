package com.example.userprofile

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity

const val PROFILE_EXTRA = "PROFILE_EXTRA"
class ProfileActivity :AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.active_profile)

    }
}